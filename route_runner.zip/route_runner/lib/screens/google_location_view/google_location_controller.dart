import 'package:get/get.dart';

class GoogleLocationController extends GetxController {

}
