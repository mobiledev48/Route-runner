class Strings {
  ///---------------------------------------- Utils ----------------------------------------

  static const buildingFamilies = "Building families and bridging dreams";

  ///-----------------------------------------auth------------------------------------------------
  static const locationList = "Location List";
  static const dashBoard = "DashBoard";

}
