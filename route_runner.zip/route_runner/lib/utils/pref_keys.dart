class PrefKeys {
  static const registerToken = "registerToken";

  static const login = "login";
  static const loginId = "loginId";
}
