package com.example.route_runner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
